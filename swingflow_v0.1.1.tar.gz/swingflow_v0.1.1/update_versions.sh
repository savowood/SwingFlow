#!/bin/bash
# Script to update all version references from v0.1 to v0.1.1

find . -type f \( -name "*.md" -o -name "*.thinkscript" -o -name "*.pine" \) -exec sed -i 's/v0\.1 /v0.1.1 /g; s/v0\.1\"/v0.1.1\"/g; s/v0\.1\'/v0.1.1\'/g; s/v0\.1-/v0.1.1-/g; s/v0\.1,/v0.1.1,/g; s/v0\.1$/v0.1.1/g; s/v0\.1)/v0.1.1)/g' {} \;

echo "Version references updated to v0.1.1"
